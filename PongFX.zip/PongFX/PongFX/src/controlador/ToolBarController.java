package controlador;

import javafx.fxml.FXML;

public class ToolBarController {

	    @FXML
	    private void abrirConfiguracion() {

	    	//TODO abrir ventana de configuración
	    	
	    }	
	
}