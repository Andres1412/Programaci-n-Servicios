package controlador;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class PongController {

	@FXML private GridPane paneToolBar;
	@FXML private AnchorPane paneMenuNavigationDrawer;
	@FXML private AnchorPane paneMenuToolbar;
	@FXML private Pane paneEffectDisable;

	@FXML
	void initialize() {

		//Cargar los 2 menús
		try {			
			VBox menuNavigationDrawer = FXMLLoader.load(getClass().getResource("/vista/MenuNavigationDrawer.fxml"));
			paneMenuNavigationDrawer.getChildren().add(menuNavigationDrawer);

			VBox menuToolbar = FXMLLoader.load(getClass().getResource("/vista/MenuToolbar.fxml"));
			paneMenuToolbar.getChildren().add(menuToolbar);

		} catch (IOException ex) {
			Logger.getLogger(PongController.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		//Al iniciar la aplicación, no se muestran los paneles
		paneMenuNavigationDrawer.setVisible(false);
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(false);   
	
	}	    
    
	//**************************************************************************
	// Acciones para los menús
	//**************************************************************************
	@FXML
	private void onMouseExitedPaneNavigationDrawer(MouseEvent event) {
		paneMenuNavigationDrawer.setVisible(false);
		paneEffectDisable.setVisible(false);
	}

	@FXML
	private void onMouseExitedPaneToolbarMenu(MouseEvent event) {
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(false);
	}

	@FXML
	private void onMouseClickedMenuNavigationDrawer(MouseEvent event) {
		paneMenuNavigationDrawer.setVisible(!paneMenuNavigationDrawer.isVisible());
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(true);
	}

	@FXML
	private void onMouseClickedMenuToolbar(MouseEvent event) {
		paneMenuToolbar.setVisible(!paneMenuToolbar.isVisible());
		paneMenuNavigationDrawer.setVisible(false);
		paneEffectDisable.setVisible(true);
	}
	
	//**************************************************************************
	// Otras funciones
	//**************************************************************************
	
	

}